import "./App.css";
import AccountDashboard from "./components/AccountDashboard";
import Header from "./components/Header";
import { AccountContextProvider } from "./context/AccountContext";

function App() {
  return (
    <>
      <div className="main-container">
        <AccountContextProvider>
          <Header />
          <AccountDashboard />
        </AccountContextProvider>
      </div>
    </>
  );
}

export default App;
